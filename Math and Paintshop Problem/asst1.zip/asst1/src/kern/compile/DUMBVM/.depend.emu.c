emu.o: ../../dev/lamebus/emu.c ../../include/types.h \
 ../../include/kern/types.h includelinks/kern/machine/types.h \
 includelinks/machine/types.h ../../include/kern/errno.h \
 ../../include/kern/fcntl.h ../../include/stat.h \
 ../../include/kern/stat.h ../../include/kern/stattypes.h \
 ../../include/lib.h ../../include/cdefs.h opt-noasserts.h \
 ../../include/array.h ../../include/uio.h ../../include/kern/iovec.h \
 ../../include/membar.h includelinks/machine/membar.h \
 ../../include/synch.h ../../include/spinlock.h ../../include/hangman.h \
 opt-hangman.h includelinks/machine/spinlock.h ../../dev/lamebus/emu.h \
 includelinks/platform/bus.h includelinks/machine/vm.h \
 ../../dev/lamebus/lamebus.h ../../include/cpu.h \
 ../../include/threadlist.h ../../include/vfs.h ../../include/emufs.h \
 ../../include/fs.h ../../include/vnode.h autoconf.h

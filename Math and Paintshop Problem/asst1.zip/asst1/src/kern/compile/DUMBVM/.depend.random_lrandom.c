random_lrandom.o: ../../dev/lamebus/random_lrandom.c \
 ../../include/types.h ../../include/kern/types.h \
 includelinks/kern/machine/types.h includelinks/machine/types.h \
 ../../include/lib.h ../../include/cdefs.h opt-noasserts.h \
 ../../dev/generic/random.h ../../include/device.h \
 ../../dev/lamebus/lrandom.h autoconf.h

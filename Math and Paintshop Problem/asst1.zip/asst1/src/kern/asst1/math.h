#ifndef _MATH_H_
#define _MATH_H_
extern void adder(void *, unsigned long);
#endif /* _MATH_H_ */

